
void func0()
{
  int i, j, t;
  int a[5] = {5, 3, 8, 1, 2};

  for (i = 0; i < 4; i++)
    for (j = 0; j < 4 - i; j++)
      if (a[j] > a[j+1])
      {
        t = a[j];
        a[j] = a[j+1];
        a[j+1] = t;
      }

  print_int(0);
  for (i = 0; i < 5; i++)
    print_int(0, a[i]);
}