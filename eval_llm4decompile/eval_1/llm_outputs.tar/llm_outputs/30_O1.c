
void func0()
{
  char *s = "swiss";
  int i, a[128] = {0};

  while (*s) {
    i = *s;
    a[i]++;
    if (a[i] > 1) {
      func1(0);
      return;
    }
    s++;
  }
  func1(0);
}