
void func0(int *a, int *b)
{
 int tmp;

 tmp = *a;
 *a = *b;
 *b = tmp;
}