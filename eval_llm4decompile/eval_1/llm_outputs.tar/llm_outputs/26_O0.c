
int func0()
{
  int n = 153;
  int sum = 0;
  int i = n;
  while (i > 0) {
    int r = i % 10;
    sum = sum + pow(r, 5.0);
    i = i / 10;
  }
  if (sum == n) {
    return func1(0);
  } else {
    return func1(0);
  }
}