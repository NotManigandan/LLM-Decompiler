
int func0()
{
  char str[7] = "Hello";
  int len = func0_1(str);
  int i;
  for (i = 0; i < len / 2; i++) {
    char tmp = str[i];
    str[i] = str[len - i - 1];
    str[len - i - 1] = tmp;
  }
  return func0_1(NULL, str);
}