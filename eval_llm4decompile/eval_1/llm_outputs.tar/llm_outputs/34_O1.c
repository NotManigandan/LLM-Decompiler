
int func0()
{
  char s[] = "hello world";
  int i;
  for (i = 0; s[i]; i++)
    if (s[i] >= 'a' && s[i] <= 'z')
      s[i] -= 'a' - 'A';
  return func1(0, s);
}