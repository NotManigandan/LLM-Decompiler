#include <stdio.h>

void func0() {
    int A[2][2] = {{1, 2}, {3, 4}}, T[2][2];
    for (int i = 0; i < 2; i++) {
        for (int j = 0; j < 2; j++) {
            T[j][i] = A[i][j];
        }
    }
    printf("Transpose Matrix:\n");
    for (int i = 0; i < 2; i++) {
        for (int j = 0; j < 2; j++) {
            printf("%d ", T[i][j]);
        }
        printf("\n");
    }
}