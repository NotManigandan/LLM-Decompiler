
int func0()
{
  int i = 12345;
  int j = 0;
  while (i) {
    i = i / 5;
    j++;
  }
  return func0(0, j);
}