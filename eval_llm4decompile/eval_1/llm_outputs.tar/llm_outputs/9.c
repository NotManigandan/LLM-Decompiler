#include <stdio.h>

void func0() {
    int num = 54321, sum = 0;
    while (num > 0) {
        sum += num % 10;
        num /= 10;
    }
    printf("Sum of Digits: %d", sum);
}