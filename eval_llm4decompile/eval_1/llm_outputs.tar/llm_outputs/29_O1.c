
int func0()
{
  char s1[] = "list";
  char s2[] = "silent";
  int i, a1[26] = {0}, a2[26] = {0};

  for (i = 0; s1[i] != '\0'; i++)
    a1[s1[i] - 'a']++;
  for (i = 0; s2[i] != '\0'; i++)
    a2[s2[i] - 'a']++;

  if (!is_anagram(a1, a2, sizeof(a1) / sizeof(a1[0])))
    return 0;

  return is_anagram(a1, a2, sizeof(a1) / sizeof(a1[0]));
}