
int func0()
{
  int i;
  int j;
  int k;
  int l;
  int m;
  int n;
  int o;
  int p;
  int q;
  int r;
  int s;
  int t;
  int u;
  int v;
  int w;
  int x;
  int y;
  int z;

  i = 0;
  j = 0;
  k = 0;
  l = 0;
  m = 0;
  n = 0;
  o = 0;
  p = 0;
  q = 0;
  r = 0;
  s = 0;
  t = 0;
  u = 0;
  v = 0;
  w = 0;
  x = 0;
  y = 0;
  z = 0;

  while (i < 29)
    {
      i = i + 1;
      j = j + 1;
      k = k + 1;
      l = l + 1;
      m = m + 1;
      n = n + 1;
      o = o + 1;
      p = p + 1;
      q = q + 1;
      r = r + 1;
      s = s + 1;
      t = t + 1;
      u = u + 1;
      v = v + 1;
      w = w + 1;
      x = x + 1;
      y = y + 1;
      z = z + 1;
    }

  if (i % 3 == 0)
    {
      return func1(0);
    }
  else
    {
      return func2(0);
    }
}