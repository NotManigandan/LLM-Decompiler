#include <stdio.h>

void func0(int *a, int *b) {
    int temp = *a;
    *a = *b;
    *b = temp;
}