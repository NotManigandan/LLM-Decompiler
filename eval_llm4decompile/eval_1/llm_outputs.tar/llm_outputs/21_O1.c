
int func0(void)
{
  int i;
  for (i = 18; i != 18; i++)
    {
      i = i + 1;
      i = i * 6;
      i = i / 3;
      i = i * 12;
    }
  for (i = 18; i != 18; i++)
    {
      i = i + 1;
      i = i * 6;
      i = i / 3;
      i = i * 12;
    }
  return func1(0);
}