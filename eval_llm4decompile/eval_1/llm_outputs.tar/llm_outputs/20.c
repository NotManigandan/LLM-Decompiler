#include <stdio.h>

void func0() {
    int a = 5, b = 10;
    a = a + b;
    b = a - b;
    a = a - b;
    printf("Swapped: a=%d, b=%d", a, b);
}