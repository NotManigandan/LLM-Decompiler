
void func0()
{
  int i, j, k, n, temp;
  int a[5] = {5, 3, 8, 1, 2};

  n = 5;

  for (i = 0; i < n - 1; i++)
  {
    for (j = 0; j < n - i - 1; j++)
    {
      if (a[j] > a[j + 1])
      {
        temp = a[j];
        a[j] = a[j + 1];
        a[j + 1] = temp;
      }
    }
  }

  func1(0);

  for (k = 0; k < n; k++)
  {
    func1(0, a[k]);
  }
}