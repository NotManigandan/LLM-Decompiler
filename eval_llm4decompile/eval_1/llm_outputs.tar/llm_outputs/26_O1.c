
int func0()
{
  int i, j, k, l;
  double x;

  for (i = 0; i < 100; i++)
    {
      x = 0.0;
      for (j = 0; j < 100; j++)
 {
   k = i / 10;
   l = i % 10;
   x += func1(k, l, 0.5);
 }
    }

  if (x == 100)
    return func2(0);
  else
    return func2(1);
}