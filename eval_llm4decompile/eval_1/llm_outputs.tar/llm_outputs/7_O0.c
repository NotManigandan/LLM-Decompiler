
int func0()
{
    char str[] = "Hello World";
    int count = 0;
    for (int i = 0; i < strlen(str); i++)
    {
        if (func1(0, str[i]))
        {
            count++;
        }
    }
    return func1(0, count);
}