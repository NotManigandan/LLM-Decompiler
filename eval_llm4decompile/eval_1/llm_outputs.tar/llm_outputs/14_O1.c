
int func0()
{
  char str[] = "Hello";
  int i, j;
  for (i = 0, j = sizeof(str) - 1; i < j; i++, j--) {
    char tmp = str[i];
    str[i] = str[j];
    str[j] = tmp;
  }
  return func1(0, str);
}