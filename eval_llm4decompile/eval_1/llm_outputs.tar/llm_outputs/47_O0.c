
int func0()
{
  char c = 'G';
  return func1(0, func0(c));
}