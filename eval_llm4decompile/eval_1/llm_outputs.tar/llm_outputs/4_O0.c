
void func0()
{
  char *p;
  char *q;
  int i;

  func1(0);
  func1(0, p);

  q = func1(p, 0);
  if (q == 0)
  {
    func1(0, p);
    func1(1);
  }

  func1(0);
  func1(0, p);

  do
  {
    i = func1(p, 0);
    if (i == 0)
    {
      func1(0, p);
      func1(1);
    }
    func1(i, q);
  } while ((i = func1(q)) != -1);

  func1(0, p);
  func1(q);
  func1(p);
}