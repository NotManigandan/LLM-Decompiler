#include <stdio.h>

void func0() {
    int num = 8, cube = num * num * num;
    printf("Cube: %d", cube);
}