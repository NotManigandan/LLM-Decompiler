#include <stdio.h>
#include <math.h>

void func0() {
    int num = 153, sum = 0, temp = num;
    while (temp > 0) {
        int digit = temp % 10;
        sum += pow(digit, 3);
        temp /= 10;
    }
    if (sum == num) printf("Armstrong Number");
    else printf("Not an Armstrong Number");
}