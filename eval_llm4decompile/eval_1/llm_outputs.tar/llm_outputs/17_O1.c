
int func0(int x, int y, int z)
{
  int i, j, k;
  int l;

  l = 0;
  for (i = 0; i < 3; i++)
    {
      j = y;
      k = z;
      while (j > 0)
 {
   l = l * 10 + k % 10;
   k = k / 10;
   j = j - 1;
 }
    }

  if (l == x)
    return func1(0);
  else
    return func2(0);
}