
int func0()
{
  int sum, n;

  n = 54321;
  sum = 0;
  while (n > 0) {
    sum = sum + n % 10;
    n = n / 10;
  }
  return func0(0, sum);
}