
int func0(void)
{
  int i, j, k, l, m, n, o, p, q, r, s, t, u, v, w, x, y, z;
  char a[16] = "D244";
  int b = 0;
  for (i = 15; i >= 0; i--)
  {
    switch (a[i])
    {
      case 'A':
        b += 10;
        break;
      case 'B':
        b += 11;
        break;
      case 'C':
        b += 12;
        break;
      case 'D':
        b += 13;
        break;
      case 'E':
        b += 14;
        break;
      case 'F':
        b += 15;
        break;
      default:
        b += a[i] - '0';
        break;
    }
    b += pow(16.0, (double)i) * (double)b;
  }
  return func1(0, b);
}