#include <stdio.h>

void func0() {
    int a = 7, b = 9;
    printf("Sum: %d", a + b);
}