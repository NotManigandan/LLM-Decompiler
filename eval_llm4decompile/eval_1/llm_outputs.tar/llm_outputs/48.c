#include <stdio.h>
#include <math.h>

void func0() {
    double base = 2.0, exponent = 5.0;
    printf("Power: %.2f", pow(base, exponent));
}