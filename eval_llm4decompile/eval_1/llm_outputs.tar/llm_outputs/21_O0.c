
int func0()
{
  int x = 12;
  int y = 18;
  int z;
  int i;

  for (i = (x > y ? x : y); (i % x) || (i % y); i++)
    ;

  z = i;

  return func1(0, z);
}