#include <stdio.h>

void func0() {
    int arr[] = {3, 5, 7, 2, 8};
    int max = arr[0], secondMax = arr[1];
    if (max < secondMax) {
        int temp = max;
        max = secondMax;
        secondMax = temp;
    }
    for (int i = 2; i < 5; i++) {
        if (arr[i] > max) {
            secondMax = max;
            max = arr[i];
        } else if (arr[i] > secondMax && arr[i] != max) {
            secondMax = arr[i];
        }
    }
    printf("Second Largest Number: %d", secondMax);
}