
void func0()
{
  int i, j;
  int a[5][5] = {
    {0, 1, 2, 3, 4},
    {2, 3, 4, 5, 6},
    {4, 5, 6, 7, 8},
    {5, 4, 3, 2, 6},
    {2, 5, 4, 3, 1}
  };
  int *b[5];

  for (i=0;i<5;i++)
    for (j=0;j<5;j++)
      b[i][j] = &(a[i][j]);

  for (i=0;i<5;i++)
  {
    for (j=0;j<5;j++)
      print_int(0, *b[i][j]);
    print_int(0, 10);
  }
}