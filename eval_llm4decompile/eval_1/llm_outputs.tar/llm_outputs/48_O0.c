
int func0()
{
  double a = 1.0;
  double b = 2.0;
  func1(a, b);
  return func2(0, 1);
}