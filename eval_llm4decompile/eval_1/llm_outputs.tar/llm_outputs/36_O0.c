
int func0()
{
  char str[] = "racecar";
  int len = func0_helper(str);
  int i;
  int palindrome = 1;
  for (i = 0; i < len/2; i++)
    {
      if (str[i] != str[len-i-1])
 {
   palindrome = 0;
   break;
 }
    }
  if (palindrome)
    {
      return func0_helper(0);
    }
  else
    {
      return func0_helper(0);
    }
}