
int func0()
{
  int i, j, k;
  i = 29;
  j = 1;
  k = 2;
  while (k * k <= i) {
    if (i % k == 0) {
      j = 0;
      break;
    }
    k = k + 1;
  }
  if (j) {
    return func1(0);
  } else {
    return func2(0);
  }
}