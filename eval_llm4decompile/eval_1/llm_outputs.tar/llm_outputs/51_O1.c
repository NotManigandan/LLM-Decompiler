
void func0()
{
  int a, b, c, d, e, f, g, h, i, j, k, l, m, n, o, p, q, r, s, t, u, v, w, x, y, z;

  a = func1(0);
  b = func1(1);
  c = func1(2);
  d = func1(3);
  e = func1(4);
  f = func1(5);
  g = func1(6);
  h = func1(7);
  i = func1(8);
  j = func1(9);
  k = func1(10);
  l = func1(11);
  m = func1(12);
  n = func1(13);
  o = func1(14);
  p = func1(15);
  q = func1(16);
  r = func1(17);
  s = func1(18);
  t = func1(19);
  u = func1(20);
  v = func1(21);
  w = func1(22);
  x = func1(23);
  y = func1(24);
  z = func1(25);

  func2(a, b, c, d, e, f, g, h, i, j, k, l, m, n, o, p, q, r, s, t, u, v, w, x, y, z);
}