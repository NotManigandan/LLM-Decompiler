
void func0()
{
  int i, j, k;
  int A[2][2] = { {1, 2}, {3, 4} };
  int B[2][2] = { {5, 6}, {7, 8} };
  int C[2][2] = { {0, 0}, {0, 0} };

  for (i = 0; i < 2; i++)
    for (j = 0; j < 2; j++)
      for (k = 0; k < 2; k++)
 C[j][i] += A[k][i] * B[j][k];

  func1(0);

  for (i = 0; i < 2; i++) {
    for (j = 0; j < 2; j++)
      func1(0, C[i][j]);
    func1('\n');
  }
}