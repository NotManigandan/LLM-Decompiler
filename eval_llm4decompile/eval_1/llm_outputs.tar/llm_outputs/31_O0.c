
int func0()
{
  int i = 2024;
  if (i % 4 == 0 && i % 100 != 0 || i % 400 == 0)
    return func1(0);
  else
    return func2(0);
}