#include <stdio.h>

void func0() {
    int num = 10;
    if (num % 2 == 0)
        printf("Even Number");
    else
        printf("Odd Number");
}