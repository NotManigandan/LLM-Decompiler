#include <stdio.h>

void func0() {
    int num = 12345, count = 0;
    while (num != 0) {
        num /= 10;
        count++;
    }
    printf("Number of Digits: %d", count);
}