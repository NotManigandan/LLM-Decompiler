
void func0()
{
  char *s;
  char *t;
  char buf[100];
  int fd;

  func1(0);
  func2(0, buf);
  s = func3(buf, 0);
  if (s == 0)
    {
      func2(0, buf);
      _exit(1);
    }
  func1(0);
  func2(0, buf);
  t = func3(buf, 0);
  if (t == 0)
    {
      func2(0, buf);
      _exit(1);
    }
  while ((fd = func4(s)) != -1)
    func5(fd, t);
  func2(0, buf);
  func6(s);
  func6(t);
}