
int func0()
{
  int x = 121;
  int y = 0;
  int z = x;
  while (x)
  {
    int r = x % 10;
    y = y * 10 + r;
    x = x / 10;
  }
  if (z == y)
  {
    return func0(0);
  }
  else
  {
    return func0(0);
  }
}