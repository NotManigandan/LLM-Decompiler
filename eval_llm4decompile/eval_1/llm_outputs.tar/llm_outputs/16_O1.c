
int func0()
{
  int i, j, k, l, m, n, o, p, q, r, s, t, u, v, w, x, y, z;
  i = 0;
  j = 1;
  k = 2;
  l = 3;
  m = 4;
  n = 5;
  o = 6;
  p = 7;
  q = 8;
  r = 9;
  s = 10;
  t = 11;
  u = 12;
  v = 13;
  w = 14;
  x = 15;
  y = 16;
  z = 17;
  for (i = 1; i <= 56; i++)
  {
    if (56 % i == 0 && 98 % i == 0)
    {
      j = i;
    }
  }
  return func1(j);
}