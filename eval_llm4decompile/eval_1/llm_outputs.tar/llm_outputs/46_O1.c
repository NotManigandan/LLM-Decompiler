
void func0()
{
  int *p;
  int *q;
  int *r;
  int *s;
  int *t;
  int *u;
  int *v;
  int *w;
  int *x;
  int *y;
  int *z;

  p = func1(0);
  q = func1(0);
  r = func1(0);
  s = func1(0);
  t = func1(0);
  u = func1(0);
  v = func1(0);
  w = func1(0);
  x = func1(0);
  y = func1(0);
  z = func1(0);

  func2(p, 4);
  func2(q, 4);
  func2(r, 4);
  func2(s, 4);
  func2(t, 4);
  func2(u, 4);
  func2(v, 4);
  func2(w, 4);
  func2(x, 4);
  func2(y, 4);
  func2(z, 4);

  func3(10);
}