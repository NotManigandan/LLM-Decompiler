#include <stdio.h>
#include <ctype.h>

void func0() {
    char str[] = "hello world";
    for (int i = 0; str[i] != '\0'; i++) {
        if (str[i] >= 'a' && str[i] <= 'z')
            str[i] = str[i] - ('a' - 'A');
    }
    printf("Uppercase: %s", str);
}