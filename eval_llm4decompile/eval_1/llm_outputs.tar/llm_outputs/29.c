#include <stdio.h>
#include <string.h>

void func0() {
    char str1[] = "listen", str2[] = "silent";
    int count1[26] = {0}, count2[26] = {0};
    for (int i = 0; str1[i] && str2[i]; i++) {
        count1[str1[i] - 'a']++;
        count2[str2[i] - 'a']++;
    }
    if (memcmp(count1, count2, sizeof(count1)) == 0)
        printf("Anagram");
    else
        printf("Not Anagram");
}