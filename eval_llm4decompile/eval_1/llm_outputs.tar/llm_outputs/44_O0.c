
int func0()
{
  double x = 1.0;
  func1(x);
  return func2(0, 1);
}