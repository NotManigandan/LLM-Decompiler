
int func0()
{
  int x = 4;
  int y = x * x;
  return func1(0, y);
}