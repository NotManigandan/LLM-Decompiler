
void func0()
{
  int i;
  int a[2] = {1, 2};
  int b[2] = {3, 4};
  int c[2] = {0, 0};

  for (i = 0; i < 2; i++)
    {
      c[0] += a[i] * 5;
      c[1] += b[i] * 7;
    }

  print_int(0);
  print_int(c[0]);
  print_int(c[1]);
  print_int(10);
  print_int(c[2]);
  print_int(c[3]);
  print_int(10);
}