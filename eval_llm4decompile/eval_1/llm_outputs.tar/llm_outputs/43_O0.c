
int func0()
{
  int a = 7;
  int b = 9;
  return func1(0, a + b);
}