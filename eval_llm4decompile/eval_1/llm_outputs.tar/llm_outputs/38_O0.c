
int func0()
{
  int a[5] = {3, 5, 7, 2, 8};
  int i, max;

  max = a[0];
  for (i = 1; i < 5; i++)
    if (a[i] > max)
      max = a[i];

  return func1(0, max);
}