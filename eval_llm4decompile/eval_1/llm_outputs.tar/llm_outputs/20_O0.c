
int func0(void)
{
  int a = 5;
  int b = 10;
  a += b;
  b = a - b;
  a -= b;
  return func1(0, a, b);
}