#include <stdio.h>
#include <ctype.h>

void func0() {
    char ch = 'G';
    printf("Lowercase: %c", tolower(ch));
}