
void func0()
{
  int i, j, k;
  int a[2][2] = { {1, 2}, {3, 4} };
  int b[2][2] = { {5, 6}, {7, 8} };
  int c[2][2];

  for (i = 0; i < 2; i++)
    for (j = 0; j < 2; j++)
      c[i][j] = a[i][j] + b[i][j];

  func1(0);

  for (i = 0; i < 2; i++) {
    for (j = 0; j < 2; j++)
      func1(0, c[i][j]);
    func1('\n');
  }
}