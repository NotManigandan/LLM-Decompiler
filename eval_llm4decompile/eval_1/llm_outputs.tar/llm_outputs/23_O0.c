
int func0()
{
  int i, j, k;

  i = 1011;
  j = 0;
  k = 0;
  while (i != 0) {
    j = j + (i % 10) * pow(2.0, k);
    i = i / 10;
    k = k + 1;
  }
  return func1(0, j);
}