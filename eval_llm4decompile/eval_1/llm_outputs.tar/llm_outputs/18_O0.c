
int func0()
{
  float x = 1.0;
  float y = x * 2.0 / 3.0 + 1.0;
  return func1(0, y);
}