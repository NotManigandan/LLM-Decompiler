#include <stdio.h>
#include <math.h>

void func0() {
    double num = 16.0;
    printf("Square Root: %.2f", sqrt(num));
}