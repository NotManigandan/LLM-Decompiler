
int func0()
{
  int x = 10;
  if (x % 2 == 0)
    return func1(0);
  else
    return func2(0);
}