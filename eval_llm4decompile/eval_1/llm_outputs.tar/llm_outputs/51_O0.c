
void func0()
{
  int i, j, k;
  int a[2][2] = { {1, 2}, {3, 4} };
  int b[2][2];

  for (i = 0; i < 2; i++)
    for (j = 0; j < 2; j++)
      b[i][j] = a[j][i];

  func1(0);

  for (i = 0; i < 2; i++)
    {
      for (j = 0; j < 2; j++)
 func1(0, b[i][j]);
      func1('\n');
    }
}