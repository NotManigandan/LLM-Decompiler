
int func0()
{
  int a[6] = {1, 2, 3, 4, 5, 6};
  int sum1 = 0;
  int sum2 = 0;
  int i;
  for (i = 0; i < 6; i++)
    if (a[i] % 2 == 0)
      sum1 += a[i];
    else
      sum2 += a[i];
  return func1(0, sum1, sum2);
}