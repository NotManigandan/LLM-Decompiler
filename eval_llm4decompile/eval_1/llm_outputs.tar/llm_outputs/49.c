#include <stdio.h>
#include <string.h>

void func0() {
    char str1[] = "Good", str2[] = "Morning";
    strcat(str1, str2);
    printf("Concatenated: %s", str1);
}