
void func0()
{
  int i, j, k, n;
  n = 10;
  j = 0;
  k = 1;
  func0_aux(0, j, k);
  for (i = 3; i <= n; i++) {
    int tmp = j + k;
    func0_aux(0, tmp, k);
    j = k;
    k = tmp;
  }
}