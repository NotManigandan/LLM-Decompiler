
int func0()
{
    char str[] = "Hello world! C programmering is fun.";
    int i = 0;
    int count = 0;

    while (str[i] != '\0')
    {
        if (str[i] == ' ' || str[i] == '\n' || str[i] == '\t')
        {
            count++;
        }
        i++;
    }

    return func1(0, count + 1);
}