
int func0()
{
  int i, sum0, sum1;
  int a[6] = {1, 2, 3, 4, 5, 6};

  sum0 = 0;
  sum1 = 0;
  for (i = 0; i < 6; i++)
    if (a[i] % 2 == 0)
      sum0 += a[i];
    else
      sum1 += a[i];

  return func1(sum0, sum1);
}