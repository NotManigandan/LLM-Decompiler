
int func0()
{
    char str[] = "Hello World";
    int count = 0;
    char *p = str;
    while (*p != '\0')
    {
        if (func1(0, *p))
        {
            count++;
        }
        p++;
    }
    return func1(0, count);
}