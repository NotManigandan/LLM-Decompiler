
int func0()
{
  int i, n, sum;

  n = 10;
  sum = 0;
  for (i = 1; i <= n; i++)
    sum = sum + i;

  return func1(0, sum);
}