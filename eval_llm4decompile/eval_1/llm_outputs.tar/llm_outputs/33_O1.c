
int func0()
{
  int i, sum = 0;
  for (i = 1; i <= 28; i++)
    if (28 % i == 0)
      sum += i;
  if (sum == 28)
    return func1(0);
  else
    return func1(1);
}