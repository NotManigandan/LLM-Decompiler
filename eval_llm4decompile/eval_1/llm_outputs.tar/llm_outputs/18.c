#include <stdio.h>

void func0() {
    float celsius = 37.0;
    float fahrenheit = (celsius * 9/5) + 32;
    printf("Fahrenheit: %.2f", fahrenheit);
}