
int func0()
{
  int i = 54321;
  int j = 0;
  while (i)
  {
    j = j * 10 + i % 10;
    i = i / 10;
  }
  return func0(0, j);
}