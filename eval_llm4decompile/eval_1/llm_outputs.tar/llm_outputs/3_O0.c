
void func0()
{
  int i;
  int n = 5;
  struct s0 a[] = {
    { 1, 0, 12.0 },
    { 5, 0, 10.0 },
    { 2, 0, 11.0 },
    { 4, 0, 12.0 },
    { 3, 0, 13.0 }
  };

  foo0(0);
  foo0(0);
  foo0(0);

  for (i = 0; i < n; i++) {
    foo0(0, i + 1);
    foo0(0, a[i].x);
    foo0(0, a[i].y);
    foo0(0, a[i].z);
  }

  foo0(0);
}