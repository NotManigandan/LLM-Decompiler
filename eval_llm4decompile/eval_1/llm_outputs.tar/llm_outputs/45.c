#include <stdio.h>
#define PI 3.14159

void func0() {
    float radius = 3.0;
    float circumference = 2 * PI * radius;
    printf("Circumference: %.2f", circumference);
}