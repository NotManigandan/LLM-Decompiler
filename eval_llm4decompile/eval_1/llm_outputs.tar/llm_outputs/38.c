#include <stdio.h>

void func0() {
    int arr[] = {3, 5, 7, 2, 8};
    int max = arr[0];
    for (int i = 1; i < 5; i++) {
        if (arr[i] > max) max = arr[i];
    }
    printf("Largest Number: %d", max);
}