
int func0()
{
  int i, j;
  char s[] = "racecar";
  int len = sizeof(s) - 1;

  for (i = len - 1, j = 0; i > len / 2; i--, j++)
    if (s[i] != s[j])
      return func1(0);

  return func1(0);
}