
int func0()
{
  int x = 8;
  int y = x * x * x;
  return func1(0, y);
}