
void func0(void)
{
  int i, j, k;

  i = 0;
  j = 1;
  k = 0;
  func1(i, j, k);

  for (i = 0; i < 8; i++) {
    k = i + j;
    func1(i, k, j);
    j = k;
  }
}