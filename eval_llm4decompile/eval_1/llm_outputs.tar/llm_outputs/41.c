#include <stdio.h>

void func0() {
    int num = 4, square = num * num;
    printf("Square: %d", square);
}