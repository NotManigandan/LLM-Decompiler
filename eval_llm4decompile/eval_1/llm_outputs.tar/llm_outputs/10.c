#include <stdio.h>

void func0() {
    int num = 5, fact = 1;
    for (int i = 1; i <= num; i++) {
        fact *= i;
    }
    printf("Factorial: %d", fact);
}