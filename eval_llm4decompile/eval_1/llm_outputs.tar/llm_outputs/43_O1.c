
int func0()
{
  return func1(0, 16);
}