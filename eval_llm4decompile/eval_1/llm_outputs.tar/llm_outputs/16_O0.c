
int func0()
{
  int i, j, k;
  i = 56;
  j = 98;
  k = 1;
  while (k <= i || k <= j) {
    if (i % k == 0 && j % k == 0) {
      int l;
      l = k;
    }
    k = k + 1;
  }
  return func1(0, l);
}