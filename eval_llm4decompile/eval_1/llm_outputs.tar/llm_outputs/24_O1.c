
void func0()
{
  int i;
  int a[5] = {3, 5, 1, 4, 2};

  func1(0);

  for (i = 0; i < 5; i++)
    func1(0, a[i]);
}