
int func0(void)
{
  char str[] = "2443";
  int i, j, k, l;
  int n;
  int result;

  for (i = strlen(str) - 1, j = 0, k = 0, l = 0; i >= 0; i--)
    {
      switch (str[i])
 {
 case 'A':
   n = 10;
   break;
 case 'B':
   n = 11;
   break;
 case 'C':
   n = 12;
   break;
 case 'D':
   n = 13;
   break;
 case 'E':
   n = 14;
   break;
 case 'F':
   n = 15;
   break;
 default:
   n = str[i] - '0';
 }
      result = j + n * pow(16, k);
      j = result;
      k++;
    }
  return func1(0, result);
}