
int func0()
{
  int a = 12345;
  int b = 0;
  while (a)
  {
    int c = a % 10;
    b = b * 10 + c;
    a = a / 10;
  }
  return func0(0, b);
}