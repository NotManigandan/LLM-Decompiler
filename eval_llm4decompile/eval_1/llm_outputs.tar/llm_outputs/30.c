#include <stdio.h>
#include <string.h>

void func0() {
    char str[] = "swiss";
    int freq[256] = {0};
    for (int i = 0; str[i]; i++) {
        freq[str[i]]++;
        if (freq[str[i]] > 1) {
            printf("First Repeating Character: %c", str[i]);
            return;
        }
    }
    printf("No Repeating Characters");
}