
int func0()
{
    char str[] = "Hello world! C programmering.";
    int i, count = 0;

    for (i = 0; str[i] != '\0'; i++)
    {
        if (str[i] == ' ' || str[i] == '\n' || str[i] == '\t')
            count++;
    }

    return func1(0, count + 1);
}