
void func0()
{
  int i, j, k, l, m, n, o, p, q, r, s, t, u, v, w, x, y, z;
  int a[10];

  a[0] = 1;
  a[1] = 2;
  a[2] = 3;
  a[3] = 4;
  a[4] = 5;
  n = 5;

  for (i = 0; i < n/2; i++)
    {
      j = a[i];
      a[i] = a[n-i-1];
      a[n-i-1] = j;
    }

  func1(0);

  for (i = 0; i < n; i++)
    {
      func1(0, a[i]);
    }
}