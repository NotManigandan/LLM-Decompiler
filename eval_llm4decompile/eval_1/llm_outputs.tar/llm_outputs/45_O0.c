
int func0()
{
  float a = 1.0;
  float b = a * 2.0;
  return func1(0, b);
}