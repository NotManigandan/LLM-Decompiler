#include <stdio.h>
#define PI 3.14159

void func0() {
    float radius = 5.0;
    float area = PI * radius * radius;
    printf("Area: %.2f", area);
}