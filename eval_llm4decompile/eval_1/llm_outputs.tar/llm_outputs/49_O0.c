
int func0()
{
    char s1[] = "Goood";
    char s2[] = "Moring";
    func1(s1, s2);
    return func1(NULL, s1);
}