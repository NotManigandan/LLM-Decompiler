
void func0()
{
  int i;
  struct s0 x[5] = {
    { 1, 0, 12, 3.14 },
    { 5, 0, 10, 3.14 },
    { 2, 0, 11, 3.14 },
    { 4, 0, 12, 3.14 },
    { 3, 0, 13, 3.14 }
  };

  func1(x[0].i);
  func1(x[0].c);
  func1(x[0].l);
  func1(x[0].d);

  for (i = 0; i < 5; i++) {
    func1(i);
    func1(x[i].i);
    func1(x[i].c);
    func1(x[i].l);
    func1(x[i].d);
  }

  func1(x[0].i);
}