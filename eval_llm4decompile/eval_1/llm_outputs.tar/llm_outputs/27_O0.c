
int func0()
{
  float x = 1.0;
  float y = x * 1.0 * x;
  return func1(0, y);
}