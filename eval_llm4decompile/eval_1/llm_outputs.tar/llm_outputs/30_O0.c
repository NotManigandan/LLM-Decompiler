
int func0()
{
  char s[] = "swiss";
  int i, a[256] = {0};

  for (i = 0; s[i]; i++) {
    a[s[i]]++;
    if (a[s[i]] > 1)
      return func1(0, s[i]);
  }

  return func1(0);
}