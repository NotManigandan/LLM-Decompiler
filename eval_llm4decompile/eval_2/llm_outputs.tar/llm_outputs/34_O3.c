
int func0()
{
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
    c -= 'a' - 'A';
  if (c >= 'a' && c <= 'z')
