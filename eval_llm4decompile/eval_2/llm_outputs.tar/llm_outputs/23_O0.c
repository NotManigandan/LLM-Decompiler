
int func0()
{
  int i = 1011;
  int sum = 0;
  int j;

  for (j = 0; i != 0; j++)
    {
      sum = sum + i % 10 * pow(2.0, j);
      i = i / 10;
    }

  return sum;
}