
int func0(void)
{
  int i, j, k;
  double x;

  x = 0;
  for (i = 0; i < 10; i++) {
    j = i * 10;
    k = j % 10;
    x += func1(j, k);
  }
  return (x == 150);
}