
int func0(void)
{
  int a = 7;
  int b = 9;
  return a + b;
}