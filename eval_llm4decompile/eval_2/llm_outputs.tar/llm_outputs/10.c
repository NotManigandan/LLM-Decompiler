#include <stdio.h>

int func0() {
    int num = 5, fact = 1;
    for (int i = 1; i <= num; i++) {
        fact *= i;
    }
    return fact;
}