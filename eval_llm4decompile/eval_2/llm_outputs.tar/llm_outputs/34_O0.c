
int func0(void)
{
  int i;
  for (i = 0; ((char *)&i)[i]; i++)
    if (((char *)&i)[i] >= 'a' && ((char *)&i)[i] <= 'z')
      ((char *)&i)[i] -= 'a' - 'A';
  return 0;
}