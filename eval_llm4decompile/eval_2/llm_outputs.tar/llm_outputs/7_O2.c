
int func0()
{
  char s[] = "Hello World";
  int i, count = 0;
  for (i = 0; i < 11; i++)
    if (func1(0, s[i]))
      count++;
  return count;
}