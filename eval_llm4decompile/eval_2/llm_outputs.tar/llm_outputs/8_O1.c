
int func0(void)
{
  int i;
  int j;
  int k;
  int l;
  int m;
  int n;
  int o;
  int p;
  int q;
  int r;
  int s;
  int t;
  int u;
  int v;
  int w;
  int x;
  int y;
  int z;

  i = 1;
  j = 2;
  k = 3;
  l = 4;
  m = 5;
  n = 6;
  o = 7;
  p = 8;
  q = 9;
  r = 10;
  s = 11;
  t = 12;
  u = 13;
  v = 14;
  w = 15;
  x = 16;
  y = 17;
  z = 18;

  while (i * i < 29)
    {
      if (i % 3 == 0)
 {
   i = i + 1;
 }
      else
 {
   i = i + 1;
 }
    }

  return 1;
}