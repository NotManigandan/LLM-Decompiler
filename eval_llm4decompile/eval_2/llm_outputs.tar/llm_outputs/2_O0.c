
int func0()
{
  int i, j, k;
  int a[2][2] = { {1, 2}, {3, 4} };
  int b[2][2];

  for (i = 0; i < 2; i++)
    for (j = 0; j < 2; j++)
      b[j][i] = a[j][i];

  return b[1][1];
}