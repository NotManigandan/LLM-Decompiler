#include <stdio.h>

struct Result {
    int evenSum;
    int oddSum;
};

struct Result func0() {
    int arr[] = {1, 2, 3, 4, 5, 6};
    struct Result res = {0, 0};
    
    for (int i = 0; i < 6; i++) {
        if (arr[i] % 2 == 0) res.evenSum += arr[i];
        else res.oddSum += arr[i];
    }
    
    return res;
}