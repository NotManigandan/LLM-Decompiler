
float func0(void)
{
  float x = 1.0;
  return 1.0 + x * 1.0 / 1.0;
}