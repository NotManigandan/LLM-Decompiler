
int func0(void)
{
  int a = 121;
  int b = 0;
  int c = a;
  while (a) {
    int d = a % 10;
    b = b * 10 + d;
    a = a / 10;
  }
  return c == b;
}