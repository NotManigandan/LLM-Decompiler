
int func0()
{
  a = 6;
  b = 8;
  c = 10;
  d = 12;
  e = 0;
  f = 0;
  return 0;
}