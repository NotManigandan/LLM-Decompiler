
int func0()
{
  int i;
  int a[4] = {1,2,3,4};
  int b[4] = {0,0,0,0};

  for (i=0;i<4;i++)
    {
      b[0] = b[0] + a[i]*5;
      b[1] = b[1] + a[i]*3;
      b[2] = b[2] + a[i]*2;
      b[3] = b[3] + a[i]*1;
    }

  for (i=0;i<4;i++)
    {
      c = c + b[i];
    }

  return 0;
}