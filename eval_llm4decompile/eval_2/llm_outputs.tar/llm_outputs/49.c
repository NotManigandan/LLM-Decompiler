#include <stdio.h>
#include <string.h>

char* func0() {
    static char str1[20] = "Good";
    char str2[] = "Morning";
    strcat(str1, str2);
    return str1;
}