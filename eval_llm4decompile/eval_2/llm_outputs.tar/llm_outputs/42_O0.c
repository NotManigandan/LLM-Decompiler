
int func0(void)
{
  int x = 8;
  int y = x * x * x;
  return y;
}