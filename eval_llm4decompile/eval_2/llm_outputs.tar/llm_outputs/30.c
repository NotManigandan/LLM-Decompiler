#include <stdio.h>
#include <string.h>

char func0() {
    char str[] = "swiss";
    int freq[256] = {0};
    for (int i = 0; str[i]; i++) {
        freq[str[i]]++;
        if (freq[str[i]] > 1) {
            return str[i];
        }
    }
    return '\0'; // No repeating character found
}