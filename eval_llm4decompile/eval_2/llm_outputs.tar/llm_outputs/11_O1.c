
void func0(int *a)
{
  int i, j, k;

  a[0] = 0;
  a[1] = 1;
  for (i = 2; i < 10; i++)
    {
      a[i] = a[i-1] + a[i-2];
    }
}