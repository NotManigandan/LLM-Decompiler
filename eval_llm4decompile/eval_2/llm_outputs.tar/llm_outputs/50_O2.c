
int func0(void)
{
  int i;
  for (i = 0; i < 100000000; i++)
    {
      a += 19;
      b += 22;
      c += 43;
      d += 50;
    }
  a = 0;
  b = 0;
  return 0;
}