
int func0(int *a)
{
  int i, j, t;
  for (i = 0; i < 4; i++)
    for (j = 0; j < 4 - i; j++)
      if (a[j] > a[j+1])
 {
   t = a[j];
   a[j] = a[j+1];
   a[j+1] = t;
 }
  return 0;
}