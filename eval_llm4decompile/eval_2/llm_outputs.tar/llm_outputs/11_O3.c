
void func0(struct struct0 *s) {
  s->a = 0;
  s->b = 1;
  s->c = 2;
  s->d = 3;
  s->e = 5;
  s->f = 8;
  s->g = 13;
  s->h = 21;
  s->i = 34;
}