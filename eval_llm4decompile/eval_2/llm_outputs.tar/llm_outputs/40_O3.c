
int func0(void)
{
  struct s0 x = { 1, 2, 3, 4, 5, 6, 7, 8 };
  if (x.a < 8)
    return 7;
  else if (x.a == 8)
    return 8;
  else
    return 9;
}