#include <stdio.h>

void func0(int fibo[]) {
    int n = 10, t1 = 0, t2 = 1, nextTerm;
    fibo[0] = t1;
    fibo[1] = t2;
    for (int i = 2; i < n; i++) {
        nextTerm = t1 + t2;
        fibo[i] = nextTerm;
        t1 = t2;
        t2 = nextTerm;
    }
}