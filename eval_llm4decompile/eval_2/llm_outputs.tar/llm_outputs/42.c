#include <stdio.h>

int func0() {
    int num = 8, cube = num * num * num;
    return cube;
}