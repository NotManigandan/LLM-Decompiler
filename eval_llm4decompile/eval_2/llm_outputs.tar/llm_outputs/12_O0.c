
int func0()
{
  int a[5] = {1, 9, 3, 7, 5};
  int i, max;

  max = a[0];
  for (i = 1; i < 5; i++)
    if (a[i] > max)
      max = a[i];

  return max;
}