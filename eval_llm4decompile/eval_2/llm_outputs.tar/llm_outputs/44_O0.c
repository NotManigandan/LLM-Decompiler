
double func0()
{
  double x = 1.0;
  double y = func1(x);
  return y;
}