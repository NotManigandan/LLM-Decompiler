
int func0()
{
  int n = 153;
  int sum = 0;
  int i = n;
  while (i > 0) {
    int r = i % 10;
    sum += pow(r, 5.0);
    i /= 10;
  }
  return sum == n;
}