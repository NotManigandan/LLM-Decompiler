
int func0()
{
  int i, sum = 0;
  for (i = 1; i <= 28; i++)
    if (28 % i == 0)
      sum += i;
  return sum == 28;
}