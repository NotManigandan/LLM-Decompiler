#include <stdio.h>

int func0() {
    int num = 28, sum = 0;
    for (int i = 1; i < num; i++) {
        if (num % i == 0) sum += i;
    }
    return sum == num;
}