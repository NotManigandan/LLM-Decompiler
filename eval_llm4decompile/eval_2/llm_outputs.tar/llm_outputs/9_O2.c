
int func0(int x)
{
  int i, y = 0;
  for (i = 0; i < 5; i++)
    {
      y += x % 10;
      x /= 10;
    }
  return y;
}