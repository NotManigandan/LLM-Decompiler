#include <stdio.h>
#define PI 3.14159

float func0() {
    float radius = 3.0;
    float circumference = 2 * PI * radius;
    return circumference;
}