
double func0()
{
  double a = 1.0;
  double b = 2.0;
  double c = func1(a, b);
  return c;
}