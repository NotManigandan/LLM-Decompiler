
float func0()
{
  float a = 1.0;
  float b = a * 2.0;
  return b;
}