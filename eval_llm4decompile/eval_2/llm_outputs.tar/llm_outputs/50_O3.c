
int func0()
{
  int i;
  for (i = 0; i < 10; i++)
    {
      a.x = a.x + b.x;
      a.y = a.y + b.y;
      a.z = a.z + b.z;
      a.w = a.w + b.w;
    }
  return 0;
}