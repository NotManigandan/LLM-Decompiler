
int
func0 (int a, int b, int c)
{
  int i, d = 0;
  for (i = 0; i < 3; i++)
    {
      d = d * 10 + (c % 10);
      c /= 10;
    }
  return d == 121;
}