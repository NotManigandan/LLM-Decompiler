#include <stdio.h>
#include <math.h>

double func0() {
    double base = 2.0, exponent = 5.0;
    return pow(base, exponent);
}