
int func0(void)
{
  return func1() + 0x1234;
}