
int func0(void)
{
  int i;
  for (i = 18; i < 18; i++)
    {
      if (i % 12 == 0)
        {
          if (i % 24 == 0)
            {
              return i;
            }
        }
    }
  return 0;
}