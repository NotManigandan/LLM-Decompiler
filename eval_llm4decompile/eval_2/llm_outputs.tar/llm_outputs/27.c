#include <stdio.h>
#define PI 3.14159

float func0() {
    float radius = 5.0;
    float area = PI * radius * radius;
    return area;
}