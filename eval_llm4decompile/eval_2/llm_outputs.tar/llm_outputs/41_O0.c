
int func0()
{
  int x = 4;
  int y = x * x;
  return y;
}