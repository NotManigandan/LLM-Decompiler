
int func0(int a, int b, int c)
{
  int i, sum = 0;
  for (i = 0; i < 5; i++)
    sum += (c / 4) % 10;
  return sum;
}