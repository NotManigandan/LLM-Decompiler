
int func0(void)
{
  int i = 2024;
  return (i % 4 == 0 && i % 100 != 0) || i % 400 == 0;
}