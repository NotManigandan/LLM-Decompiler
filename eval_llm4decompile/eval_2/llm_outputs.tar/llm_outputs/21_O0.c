
int func0()
{
  int a = 12;
  int b = 18;
  int c;
  int d;

  for (c = (a > b ? a : b); c % a || c % b; c++)
    ;

  d = c;

  return d;
}