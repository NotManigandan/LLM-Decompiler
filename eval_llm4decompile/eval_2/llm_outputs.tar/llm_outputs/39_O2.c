
int func0(int a, int b, int c)
{
  int i, j, k;
  int sum = 0;
  for (i = 0; i < 5; i++)
    {
      j = a * 10;
      k = b / 5;
      sum = sum * 10 + j + k;
    }
  return sum;
}