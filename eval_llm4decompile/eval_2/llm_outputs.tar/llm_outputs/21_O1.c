
int func0(void)
{
  int i;
  for (i = 18; i != 18*3; i++)
    ;
  for (i = 18; i != 18*9; i++)
    ;
  return i;
}