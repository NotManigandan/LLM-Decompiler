
int func0()
{
  char s[] = "swiss";
  int i, count[256] = {0};

  for (i = 0; s[i]; i++) {
    count[s[i]]++;
    if (count[s[i]] > 1)
      return s[i];
  }

  return 0;
}