
unsigned long func0(void)
{
  int a[6] = {1, 2, 3, 4, 5, 6};
  int i;
  unsigned long sum1 = 0;
  unsigned long sum2 = 0;

  for (i = 0; i < 6; i++)
    if (a[i] % 2 == 0)
      sum1 += a[i];
    else
      sum2 += a[i];

  return sum1;
}