#include <stdio.h>

int func0() {
    int a = 7, b = 9;
    return a + b;
}