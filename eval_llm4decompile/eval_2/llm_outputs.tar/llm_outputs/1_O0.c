
int func0(int *a, int *b)
{
  int c;
  c = *a;
  *a = *b;
  *b = c;
  return 0;
}