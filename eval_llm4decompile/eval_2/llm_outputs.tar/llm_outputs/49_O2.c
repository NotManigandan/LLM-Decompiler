
int func0()
{
  char s[] = "Miron";
  func1(0, s);
  return 0;
}