
int func0()
{
  int i, max, a[5] = {3, 5, 7, 2, 8};

  max = a[0];
  for (i = 1; i < 5; i++)
    if (a[i] > max)
      max = a[i];

  return max;
}