
int func0()
{
  char str[] = "This is a test string.";
  char *p = str;
  int count = 0;
  char c;

  while ((c = *p++) != '\0')
    {
      count++;
      if (c == ' ' || c == '\t' || c == '\n')
        count++;
    }

  return count;
}