
int func0(int a, int b, int c)
{
  int i, j, k;
  for (i = 0; i < 5; i++)
    {
      j = a * 10;
      k = b / 2;
      a = (j + k) % 10;
    }
  return a;
}