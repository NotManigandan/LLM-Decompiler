#include <stdio.h>

int func0() {
    int year = 2024;
    if ((year % 4 == 0 && year % 100 != 0) || (year % 400 == 0))
        return 1; // Is a leap year
    else
        return 0; // Not a leap year
}