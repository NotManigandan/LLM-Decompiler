
int func0()
{
  int i, j;
  int a[2][2] = { { 9, 8 }, { 7, 6 } };
  int b[2][2] = { { 5, 4 }, { 3, 2 } };

  for (i = 0; i < 2; i++)
    for (j = 0; j < 2; j++)
      a[i][j] -= b[i][j];

  g = 0;
  h = 0;

  return 0;
}