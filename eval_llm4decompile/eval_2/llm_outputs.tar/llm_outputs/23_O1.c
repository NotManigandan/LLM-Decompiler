
int func0(void)
{
  int i, j, k, l;
  double x;

  x = 0.0;
  for (i = 0; i < 4; i++) {
    x += func1(1.0, (double)i) * (j = (k = 1011) % 10);
    k /= 10;
  }
  return (int)x;
}