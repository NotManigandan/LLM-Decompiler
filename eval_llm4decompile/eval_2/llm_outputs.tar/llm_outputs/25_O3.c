
struct struct0 func0()
{
  struct struct0 s;
  s.a = 12;
  s.b = 9;
  return s;
}