
int func0()
{
  int i;
  int j;
  int k;
  int l;
  int m;
  int n;
  int o;
  int p;
  int q;
  int r;
  int s;
  int t;
  int u;
  int v;
  int w;
  int x;
  int y;
  int z;

  i = 0;
  j = 1;
  k = 2;
  l = 3;
  m = 4;
  n = 5;
  o = 6;
  p = 7;
  q = 8;
  r = 9;
  s = 10;
  t = 11;
  u = 12;
  v = 13;
  w = 14;
  x = 15;
  y = 16;
  z = 17;

  return i + j + k + l + m + n + o + p + q + r + s + t + u + v + w + x + y + z;
}