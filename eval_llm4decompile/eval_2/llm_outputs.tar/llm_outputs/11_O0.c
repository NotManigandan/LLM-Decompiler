
void func0(int *p)
{
  int i, j, k, n = 10;
  int a, b;

  a = 0;
  b = 1;
  p[0] = a;
  p[1] = b;
  for (i = 2; i < n; i++) {
    k = a + b;
    p[i] = k;
    a = b;
    b = k;
  }
}