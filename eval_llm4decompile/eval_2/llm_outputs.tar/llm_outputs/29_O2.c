
int func0()
{
  char s1[] = "listen";
  char s2[] = "silent";
  int i, c1[26] = {0}, c2[26] = {0};

  for (i = 0; s1[i]; i++)
    c1[s1[i] - 'a']++;
  for (i = 0; s2[i]; i++)
    c2[s2[i] - 'a']++;

  return !compare(c1, c2, 26);
}