
int func0(int x)
{
  int i;
  int sum = 0;
  for (i = 0; i < 3; i++)
    {
      sum += func1(x % 10, 1.0);
      x /= 10;
    }
  return sum == 153;
}