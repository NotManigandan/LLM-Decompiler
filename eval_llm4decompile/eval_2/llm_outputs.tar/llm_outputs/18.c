#include <stdio.h>

float func0() {
    float celsius = 37.0;
    return (celsius * 9/5) + 32;
}