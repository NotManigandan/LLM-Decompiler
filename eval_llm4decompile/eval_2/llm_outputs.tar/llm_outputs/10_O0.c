
int func0()
{
  int i, n, result;

  n = 5;
  result = 1;
  for (i = 1; i <= n; i++)
    result *= i;

  return result;
}