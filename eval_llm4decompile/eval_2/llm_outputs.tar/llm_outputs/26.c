#include <stdio.h>
#include <math.h>

int func0() {
    int num = 153, sum = 0, temp = num;
    while (temp > 0) {
        int digit = temp % 10;
        sum += pow(digit, 3);
        temp /= 10;
    }
    return (sum == num) ? 1 : 0; // 1 if Armstrong, 0 if not
}