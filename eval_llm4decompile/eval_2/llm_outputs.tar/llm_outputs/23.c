#include <stdio.h>
#include <math.h>

int func0() {
    int binary = 1011, decimal = 0, i = 0;
    while (binary != 0) {
        decimal += (binary % 10) * pow(2, i);
        binary /= 10;
        i++;
    }
    return decimal;
}