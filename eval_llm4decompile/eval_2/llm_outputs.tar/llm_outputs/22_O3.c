
int func0(int a, int b)
{
    return func1(a, b);
}