
int func0(void)
{
  char s[] = "racecar";
  int i;
  for (i = 0; i < 7; i++)
    if (s[i] != s[7 - i - 1])
      return 0;
  return 1;
}