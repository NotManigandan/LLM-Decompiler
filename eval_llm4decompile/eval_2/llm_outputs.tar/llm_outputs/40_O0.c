
int func0()
{
  int a[5] = {3, 5, 7, 2, 8};
  int i, max, second;

  max = a[0];
  second = a[1];
  if (max < second)
  {
    int tmp = max;
    max = second;
    second = tmp;
  }

  for (i = 2; i < 5; i++)
  {
    if (max < a[i])
    {
      second = max;
      max = a[i];
    }
    else if (second < a[i] && max != a[i])
    {
      second = a[i];
    }
  }

  return second;
}