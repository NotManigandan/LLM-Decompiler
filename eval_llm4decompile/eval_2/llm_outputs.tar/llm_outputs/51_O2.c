
int func0(void)
{
  struct s0 x;
  x.a = 1;
  x.b = 2;
  x.c = 3;
  x.d = 4;
  x.e = 0;
  x.f = 0;
  x.g = 0;
  x.h = 0;
  return 0;
}