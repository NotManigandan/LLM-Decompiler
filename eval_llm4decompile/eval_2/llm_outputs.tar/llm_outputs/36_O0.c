
int func0()
{
  char str[] = "racecar";
  int len = strlen(str);
  int i;
  int result = 1;

  for (i = 0; i < len/2; i++)
    if (str[i] != str[len-i-1])
      {
 result = 0;
 break;
      }

  return result;
}