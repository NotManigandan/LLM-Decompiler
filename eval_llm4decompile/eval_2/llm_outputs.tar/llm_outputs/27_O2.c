
float func0(void)
{
 return f;
}