#include <stdio.h>
#include <ctype.h>

char func0() {
    char ch = 'G';
    return tolower(ch);
}