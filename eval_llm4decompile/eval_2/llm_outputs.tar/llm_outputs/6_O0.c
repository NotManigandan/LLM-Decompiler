
int func0()
{
  int i = 12345;
  int j = 0;
  while (i)
  {
    int k = i % 10;
    j = j * 10 + k;
    i = i / 10;
  }
  return j;
}