
struct s0 func0()
{
  struct s0 s;
  int i;
  int a[6] = {1, 2, 3, 4, 5, 6};

  s.x = 0;
  s.y = 0;
  for (i = 0; i < 6; i++)
    {
      if (a[i] % 2 == 0)
        s.x += a[i];
      else
        s.y += a[i];
    }

  return s;
}