
int func0(int x)
{
  int i, y;
  y = 0;
  for (i = 0; i < 5; i++)
    {
      y = y * 10 + (x % 10);
      x = x / 10;
    }
  return y;
}