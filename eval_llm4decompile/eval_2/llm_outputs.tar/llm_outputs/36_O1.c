
int func0(void)
{
  char str[] = "racecar";
  int i, j;

  for (i = j = sizeof(str) - 1; i > 0 && str[--i] == str[j--]; i--)
    ;

  if (i > 0)
    return 0;
  else
    return 1;
}