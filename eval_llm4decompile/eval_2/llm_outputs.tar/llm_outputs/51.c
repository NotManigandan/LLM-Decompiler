#include <stdio.h>
#include <stdlib.h>

int** func0() {
    int A[2][2] = {{1, 2}, {3, 4}};
    static int T[2][2];
    
    for (int i = 0; i < 2; i++) {
        for (int j = 0; j < 2; j++) {
            T[j][i] = A[i][j];
        }
    }
    
    static int* result[2];
    result[0] = T[0];
    result[1] = T[1];
    
    return result;
}