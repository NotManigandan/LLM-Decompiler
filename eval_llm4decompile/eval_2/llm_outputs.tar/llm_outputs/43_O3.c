
int func0(void)
{
  return 16;
}