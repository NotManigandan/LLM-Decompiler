#include <stdio.h>

int func0() {
    int n = 10, sum = 0;
    for (int i = 1; i <= n; i++) {
        sum += i;
    }
    return sum;
}