
int func0(void)
{
  char *p = str;
  while (*p)
    {
      if (*p >= 'a' && *p <= 'z')
 *p -= 32;
      p++;
    }
  return 0;
}