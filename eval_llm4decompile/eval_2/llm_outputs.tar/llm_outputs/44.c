#include <stdio.h>
#include <math.h>

double func0() {
    double num = 16.0;
    return sqrt(num);
}