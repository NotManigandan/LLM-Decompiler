#include <stdio.h>

int func0() {
    int arr[] = {1, 9, 3, 7, 5};
    int max = arr[0];
    for (int i = 1; i < 5; i++) {
        if (arr[i] > max) max = arr[i];
    }
    return max;
}