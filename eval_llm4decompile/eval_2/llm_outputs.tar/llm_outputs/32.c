#include <stdio.h>

int func0() {
    int num = 12345, count = 0;
    while (num != 0) {
        num /= 10;
        count++;
    }
    return count;
}