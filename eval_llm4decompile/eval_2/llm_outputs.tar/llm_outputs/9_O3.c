
int func0(void)
{
  return 15;
}