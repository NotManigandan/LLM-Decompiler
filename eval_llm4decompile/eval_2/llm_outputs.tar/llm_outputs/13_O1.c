
int func0()
{
    char str[] = "Hello world! C programmering is fun.";
    int i = 0;
    while (str[i] != '\0')
    {
        if (str[i] != ' ' && str[i] != '\n' && str[i] != '\t')
        {
            i++;
        }
        else
        {
            i++;
        }
    }
    return i + 1;
}