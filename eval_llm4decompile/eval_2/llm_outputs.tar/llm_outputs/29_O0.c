
int func0()
{
    char s1[] = "listen";
    char s2[] = "silent";
    int a1[26] = {0};
    int a2[26] = {0};
    int i, j;

    if (func0_1(s1) != func0_1(s2))
        return 0;

    for (i = 0; s1[i] != '\0'; i++)
        a1[s1[i] - 'a']++;

    for (j = 0; s2[j] != '\0'; j++)
        a2[s2[j] - 'a']++;

    return !func0_1(a1, a2, sizeof(a1));
}