
struct struct0 func0()
{
  struct struct0 s;
  int i;
  int a[6] = {1,2,3,4,5,6};

  s.a = 0;
  s.b = 0;
  for (i = 0; i < 6; i++)
    {
      if (a[i] % 2 == 0)
        s.a += a[i];
      else
        s.b += a[i];
    }
  return s;
}