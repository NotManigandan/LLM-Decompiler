#include <stdio.h>

char func0() {
    char ch = 'e';
    if (ch == 'A' || ch == 'E' || ch == 'I' || ch == 'O' || ch == 'U' ||
        ch == 'a' || ch == 'e' || ch == 'i' || ch == 'o' || ch == 'u') {
        return 'V';
    } else {
        return 'C';
    }
}