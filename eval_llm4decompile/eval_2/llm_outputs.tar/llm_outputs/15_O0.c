
int func0(int x)
{
  return !(x & 1);
}