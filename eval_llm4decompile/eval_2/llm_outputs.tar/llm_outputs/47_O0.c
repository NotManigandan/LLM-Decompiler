
int func0()
{
  char c = 'G';
  return func1(c);
}