
int func0()
{
  char c = 'e';
  if (c == 'A' || c == 'E' || c == 'I' || c == 'O' || c == 'U' ||
      c == 'a' || c == 'e' || c == 'i' || c == 'o' || c == 'u')
    return func1();
  else
    return func2();
}