
int func0(void)
{
  int i;
  for (i = 3; i*i <= 29; i++)
    if (i == 29)
      return 0;
  return 1;
}