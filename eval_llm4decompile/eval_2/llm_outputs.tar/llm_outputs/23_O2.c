
int func0()
{
  int i, j, k;
  double x;

  x = 0.0;
  for (i=0; i<4; i++) {
    j = func1(1.0, i);
    k = func2(j);
    x += k/10.0;
  }
  return x;
}