
int func0()
{
  a = 1;
  b = 2;
  c = 3;
  d = 4;
  e = 0;
  f = 0;
  return 0;
}