
int func0()
{
  char a[5] = "race";
  char b[5] = "care";
  int i;
  for (i = 0; i < 4; i++)
    if (a[i] != b[i])
      return 0;
  return 1;
}