
int func0()
{
  int i = 0;
  char s[] = "Hello World";
  if (func1(i, s[0])) i++;
  if (func1(i, s[1])) i++;
  if (func1(i, s[2])) i++;
  if (func1(i, s[3])) i++;
  if (func1(i, s[4])) i++;
  if (func1(i, s[5])) i++;
  if (func1(i, s[6])) i++;
  if (func1(i, s[7])) i++;
  if (func1(i, s[8])) i++;
  if (func1(i, s[9])) i++;
  if (func1(i, s[10])) i++;
  if (func1(i, s[11])) i++;
  return i;
}