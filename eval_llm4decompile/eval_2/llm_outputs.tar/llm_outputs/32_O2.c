
int func0(void)
{
  return 5;
}