
int func0()
{
  int i, j, k;
  int A[2][2] = { {1, 2}, {3, 4} };
  int B[2][2] = { {5, 6}, {7, 8} };

  for (k = 0; k < 2; k++)
    for (i = 0; i < 2; i++)
      for (j = 0; j < 2; j++)
 A[i][k] += A[i][j] * B[j][k];

  x = 0;
  y = 0;
  return 0;
}