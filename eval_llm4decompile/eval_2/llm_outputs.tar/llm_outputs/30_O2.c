
void func0()
{
  int i;
  int a[128] = {0};
  char *s = "swiss";
  while (*s)
    if (++a[*s++] > 1)
      i = 1;
}