
int func0(void)
{
  int i = 54321;
  int sum = 0;
  while (i > 0)
    {
      sum += i % 10;
      i /= 10;
    }
  return sum;
}