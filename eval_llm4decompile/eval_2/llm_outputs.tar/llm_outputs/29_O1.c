
int func0()
{
    char s1[] = "list";
    char s2[] = "silent";
    int a1[26] = {0};
    int a2[26] = {0};
    int i;

    for (i = 0; s1[i] != '\0'; i++)
        a1[s1[i] - 'a']++;
    for (i = 0; s2[i] != '\0'; i++)
        a2[s2[i] - 'a']++;

    return !compare(a1, a2, 26);
}