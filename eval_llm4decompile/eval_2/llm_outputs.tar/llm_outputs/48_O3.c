
double func0(void)
{
  return 1.0;
}