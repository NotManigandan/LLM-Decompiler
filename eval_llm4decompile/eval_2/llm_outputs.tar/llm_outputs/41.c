#include <stdio.h>

int func0() {
    int num = 4, square = num * num;
    return square;
}