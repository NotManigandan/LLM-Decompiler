
int func0()
{
  int tmp;
  if (a > b) { tmp = a; a = b; b = tmp; }
  if (b > c) { tmp = b; b = c; c = tmp; }
  if (c > d) { tmp = c; c = d; d = tmp; }
  if (a > b) { tmp = a; a = b; b = tmp; }
  if (b > c) { tmp = b; b = c; c = tmp; }
  if (a > b) { tmp = a; a = b; b = tmp; }
  if (c > d) { tmp = c; c = d; d = tmp; }
  if (b > c) { tmp = b; b = c; c = tmp; }
  if (a > b) { tmp = a; a = b; b = tmp; }
  return 0;
}