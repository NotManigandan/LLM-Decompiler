
int func0(void)
{
  struct s0 x;
  x.a = 6;
  x.b = 8;
  x.c = 10;
  x.d = 12;
  x.e = 0;
  x.f = 0;
  x.g = 0;
  return 0;
}