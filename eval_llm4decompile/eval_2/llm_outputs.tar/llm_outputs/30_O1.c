
void func0()
{
  char s[] = "swiss";
  int i, a[128];

  for (i = 0; i < 128; i++)
    a[i] = 0;

  for (i = 0; s[i] != '\0'; i++)
    if (++a[s[i]] > 1)
      break;
}