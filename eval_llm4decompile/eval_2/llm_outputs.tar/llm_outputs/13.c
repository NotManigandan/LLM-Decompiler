#include <stdio.h>
#include <string.h>

int func0() {
    char str[] = "Hello world! Welcome to C programming.";
    int count = 0;
    for (int i = 0; str[i] != '\0'; i++) {
        if (str[i] == ' ' || str[i] == '\n' || str[i] == '\t')
            count++;
    }
    return count + 1;
}