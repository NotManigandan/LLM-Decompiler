#include <stdio.h>

int func0() {
    int num = 54321, sum = 0;
    while (num > 0) {
        sum += num % 10;
        num /= 10;
    }
    return sum;
}