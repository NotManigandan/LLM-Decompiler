
int func0()
{
  int i;
  for (i = 0; i < 4; i++)
    {
      a = b = c = d = 4;
      e = f = 0;
    }
  return 0;
}