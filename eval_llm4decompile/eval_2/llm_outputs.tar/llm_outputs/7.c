#include <stdio.h>
#include <string.h>

int func0() {
    char str[] = "Hello World";
    int count = 0;
    for (int i = 0; i < strlen(str); i++) {
        if (strchr("AEIOUaeiou", str[i])) {
            count++;
        }
    }
    return count;
}