
int func0()
{
  char s[] = "Moringa";
  func1(0, s);
  return 0;
}