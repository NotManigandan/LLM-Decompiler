#include <stdio.h>

int func0() {
    int a = 12, b = 18, lcm;
    int max = (a > b) ? a : b;
    while (1) {
        if (max % a == 0 && max % b == 0) {
            lcm = max;
            break;
        }
        max++;
    }
    return lcm;
}