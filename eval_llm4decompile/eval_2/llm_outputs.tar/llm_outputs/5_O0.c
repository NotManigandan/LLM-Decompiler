
int func0()
{
  int i, n, sum;

  n = 28;
  sum = 0;
  for (i = 1; i < n; i++)
    if (n % i == 0)
      sum = sum + i;
  return sum == n;
}