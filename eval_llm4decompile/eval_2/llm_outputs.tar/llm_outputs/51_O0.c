
int func0()
{
  int i, j;
  int a[2][2] = { {1, 2}, {3, 4} };

  for (i = 0; i < 2; i++)
    for (j = 0; j < 2; j++)
      b[i][j] = a[j][i];

  c = 0;
  d = 0;

  return 0;
}