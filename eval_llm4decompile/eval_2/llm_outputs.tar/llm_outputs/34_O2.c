
int func0()
{
  char *p = str;
  char *q = str;
  while (*p) {
    if (*p >= 'a' && *p <= 'z')
      *q = *p - 'a' + 'A';
    else
      *q = *p;
    p++;
    q++;
  }
  return 0;
}