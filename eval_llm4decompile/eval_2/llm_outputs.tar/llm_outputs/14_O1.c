
void func0(char *str)
{
    int i, j, len;
    char tmp;

    len = -1;
    while (str[++len] != '\0')
        ;

    for (i = 0, j = len - 1; i < len / 2; i++, j--) {
        tmp = str[i];
        str[i] = str[j];
        str[j] = tmp;
    }
}