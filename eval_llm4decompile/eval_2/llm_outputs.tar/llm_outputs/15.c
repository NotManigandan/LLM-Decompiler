#include <stdio.h>

int func0(int num) {
    return (num % 2 == 0) ? 1 : 0;
}