
int func0(void)
{
  return func1() + 8;
}