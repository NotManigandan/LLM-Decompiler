
int func0(int a, int b, int c)
{
  int i, sum = 0;
  for (i = 0; i < 3; i++)
    sum = sum * 10 + (c % 10);
  return sum == func1(a, b);
}